import React from "react";
import ReactDOM from "react-dom";
import { Button } from "./components/Button";

import "./styles.css";

export class App extends React.Component {
  state = {
    participantes: [],
    premiados: [],
    inputValue: ""
  };

  changeValue = event => {
    const value = event.target.value;
    this.setState({ inputValue: value });
  };

  addParticipante = () => {
    this.setState({
      participantes: [...this.state.participantes, this.state.inputValue],
      inputValue: ""
    });
  };

  sortear = () => {
    const length = this.state.participantes.length;
    const participantes = this.state.participantes;

    if (length < 1) {
      alert("Não existe nenhum participante");
      return;
    }

    const numero = Math.floor(Math.random() * length);
    const sorteado = participantes[numero];
    const novosParticipantes = participantes.filter((x, index) => {
      return index !== numero;
    });

    this.setState({
      premiados: [...this.state.premiados, sorteado],
      participantes: novosParticipantes
    });
  };

  render() {
    return (
      <div className="App">
        <h1>Participantes</h1>
        <input value={this.state.inputValue} onChange={this.changeValue} />
        <Button theme="secondary" onClick={this.addParticipante}>
          adicionar
        </Button>

        <ul>
          {this.state.participantes.map((item, index) => {
            return <li key={index}>{item}</li>;
          })}
        </ul>

        <h1>Premiados</h1>
        <Button theme="secondary" onClick={this.sortear}>
          Sortear Agora!
        </Button>

        <ul>
          {this.state.premiados.map((item, index) => {
            return <li key={index}>{item}</li>;
          })}
        </ul>
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
