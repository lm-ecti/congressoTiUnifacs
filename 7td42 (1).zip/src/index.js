import React from "react";
import ReactDOM from "react-dom";
import { Button } from "./components/Button";

import "./styles.css";

export class App extends React.Component {
  state = {
    participantes: [],
    premiados: [],
    inputValue: ""
  };

  changeValue = event => {
    const value = event.target.value;
    this.setState({ inputValue: value });
  };

  addParticipante = () => {
    this.setState({
      participantes: [...this.state.participantes, this.state.inputValue],
      inputValue: ""
    });
  };

  render() {
    return (
      <div className="App">
        <h1>Participantes</h1>
        <input value={this.state.inputValue} onChange={this.changeValue} />
        <Button theme="secondary" onClick={this.addParticipante}>
          adicionar
        </Button>

        <ul>
          {this.state.participantes.map((item, index) => {
            return <li key={index}>{item}</li>;
          })}
        </ul>

        <h1>Premiados</h1>
        <Button theme="secondary">Sortear Agora!</Button>
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
